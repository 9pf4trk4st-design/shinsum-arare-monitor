import os
import re
import time
import hashlib
from datetime import datetime

import requests
from dotenv import load_dotenv
from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeoutError

from config import (
    LOGIN_URL,
    USER_SELECTORS,
    PASSWORD_SELECTORS,
    LOGIN_BUTTON_SELECTORS,
    ARARE_KEYWORDS,
    RACE_PATTERNS,
)

load_dotenv()

USER = os.getenv("SHINSUM_USER", "")
PASSWORD = os.getenv("SHINSUM_PASSWORD", "")
NTFY_TOPIC = os.getenv("NTFY_TOPIC", "")
NTFY_SERVER = os.getenv("NTFY_SERVER", "https://ntfy.sh").rstrip("/")
INTERVAL = int(os.getenv("CHECK_INTERVAL", "120"))
HEADLESS = os.getenv("HEADLESS", "true").lower() != "false"

# 通知済みIDをメモリ保持（プログラム再起動時はリセット）
notified = set()


def first_visible(page, selectors):
    for selector in selectors:
        try:
            loc = page.locator(selector).first
            if loc.is_visible(timeout=800):
                return loc
        except Exception:
            pass
    return None


def login_if_needed(page):
    # ログイン画面らしさを判定
    password_box = first_visible(page, PASSWORD_SELECTORS)
    if not password_box:
        return True

    if not USER or not PASSWORD:
        raise RuntimeError(".env に SHINSUM_USER / SHINSUM_PASSWORD を設定してください。")

    user_box = first_visible(page, USER_SELECTORS)
    if not user_box:
        raise RuntimeError("ログインID欄を見つけられません。config.py の USER_SELECTORS を調整してください。")

    user_box.fill(USER)
    password_box.fill(PASSWORD)

    button = first_visible(page, LOGIN_BUTTON_SELECTORS)
    if button:
        button.click()
    else:
        password_box.press("Enter")

    try:
        page.wait_for_load_state("networkidle", timeout=10000)
    except PlaywrightTimeoutError:
        pass

    # パスワード欄が消えればログイン成功とみなす
    try:
        if not page.locator('input[type="password"]').first.is_visible(timeout=1500):
            return True
    except Exception:
        return True

    print("[WARN] ログイン後もパスワード欄が残っています。CAPTCHA等の可能性があります。")
    return False


def extract_arare(page):
    text = page.locator("body").inner_text(timeout=10000)
    if not any(k in text for k in ARARE_KEYWORDS):
        return []

    # 「荒れ注意」を含む行を中心に抽出
    lines = [x.strip() for x in text.splitlines() if x.strip()]
    hits = []

    for i, line in enumerate(lines):
        if not any(k in line for k in ARARE_KEYWORDS):
            continue

        context = " | ".join(lines[max(0, i-4):min(len(lines), i+5)])

        race = None
        for pat in RACE_PATTERNS:
            m = re.search(pat, context)
            if m:
                race = m.group(1) + "R"
                break

        # 競艇24場
        stadiums = [
            "桐生","戸田","江戸川","平和島","多摩川","浜名湖","蒲郡",
            "常滑","津","三国","びわこ","住之江","尼崎","鳴門","丸亀",
            "児島","宮島","徳山","下関","若松","芦屋","福岡","唐津","大村"
        ]
        stadium = next((s for s in stadiums if s in context), None)

        # 同一レースをまとめるための安定したキー
        key_source = f"{stadium}|{race}|{context}"
        key = hashlib.sha256(key_source.encode("utf-8")).hexdigest()[:16]

        hits.append({
            "key": key,
            "stadium": stadium or "場不明",
            "race": race or "R不明",
            "context": context,
        })

    return hits


def notify(item):
    title = f"🚨 荒れ注意 {item['stadium']} {item['race']}"
    message = f"{item['context']}\n検出: {datetime.now():%Y-%m-%d %H:%M:%S}"

    if not NTFY_TOPIC:
        print("[NOTIFY]", title, message)
        return

    url = f"{NTFY_SERVER}/{NTFY_TOPIC}"
    r = requests.post(
        url,
        data=message.encode("utf-8"),
        headers={
            "Title": title,
            "Priority": "high",
            "Tags": "rotating_light,ship",
        },
        timeout=15,
    )
    r.raise_for_status()
    print("[NOTIFY SENT]", title)


def main():
    print("シンsum 荒れ注意監視を開始")
    print(f"チェック間隔: {INTERVAL}秒")

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=HEADLESS)
        context = browser.new_context()
        page = context.new_page()

        while True:
            try:
                page.goto(LOGIN_URL, wait_until="domcontentloaded", timeout=30000)

                if not login_if_needed(page):
                    print("[WARN] ログインできません。次回チェックします。")
                    time.sleep(INTERVAL)
                    continue

                hits = extract_arare(page)
                print(f"[{datetime.now():%H:%M:%S}] 荒れ注意検出: {len(hits)}件")

                for item in hits:
                    if item["key"] not in notified:
                        notify(item)
                        notified.add(item["key"])

            except Exception as e:
                print("[ERROR]", repr(e))

            time.sleep(INTERVAL)


if __name__ == "__main__":
    main()
