# 実サイトに合わせてここを調整する設定ファイル

LOGIN_URL = "https://boatrace-shinsum.com/"

# ログインフォーム候補。上から順に試します。
USER_SELECTORS = [
    'input[name="email"]',
    'input[name="username"]',
    'input[name="user_id"]',
    'input[type="email"]',
    'input[type="text"]',
]

PASSWORD_SELECTORS = [
    'input[name="password"]',
    'input[type="password"]',
]

LOGIN_BUTTON_SELECTORS = [
    'button[type="submit"]',
    'input[type="submit"]',
    'button:has-text("ログイン")',
]

# 「荒れ注意」を探すキーワード。
ARARE_KEYWORDS = ["荒れ注意"]

# レース番号を拾うための正規表現候補
RACE_PATTERNS = [
    r'([1-9]|1[0-2])R',
    r'([1-9]|1[0-2]) レース',
]
